#!/bin/bash
# Here you can execute commands, if script exited with errors

echo -e "There are an error during update \
         \nPlease check output here or in logfile\n"
