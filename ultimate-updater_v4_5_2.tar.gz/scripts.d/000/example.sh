#!/bin/bash

echo "make something spezial :)"

exit 0