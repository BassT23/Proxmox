# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 4.x     | :white_check_mark: |
| < 4.0   | :x:                |

## Reporting a Vulnerability

Issues can be reported [here](https://github.com/BassT23/Proxmox/issues) or per Discord
