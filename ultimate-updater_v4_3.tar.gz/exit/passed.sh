#!/bin/bash
# Here you can execute commands, if script exited correctly

echo -e "All fine, have a nice day\n"
